# OUTPUT TERMS OF USE

These structure predictions were generated using boltz2 model
weights, which are licensed under the MIT License.

The AlphaFold 3 Output Terms of Use (which restrict commercial use) do
NOT apply to these outputs -- they were not produced with AlphaFold 3
parameters. Use is subject to the MIT License alone.

Weights: https://github.com/jwohlwend/boltz

AlphaFold 3 code is copyright Google DeepMind, also Apache 2.0:
https://github.com/google-deepmind/alphafold3
